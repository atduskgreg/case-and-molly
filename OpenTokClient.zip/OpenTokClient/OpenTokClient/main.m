//
//  main.m
//  OpenTokClient
//
//  Created by Greg Borenstein on 1/17/14.
//  Copyright (c) 2014 Greg Borenstein. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[])
{
    return NSApplicationMain(argc, argv);
}
